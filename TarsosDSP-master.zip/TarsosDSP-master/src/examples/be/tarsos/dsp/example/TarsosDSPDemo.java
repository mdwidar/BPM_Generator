package be.tarsos.dsp.example;

public interface TarsosDSPDemo {
	
	public String name();
	public String description();
	public void start();
}
